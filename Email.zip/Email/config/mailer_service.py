import smtplib
from prefect.blocks.system import JSON

class SMTPConfig:
    config = JSON.load("smtp-server-config", _sync=True).value

def get_credential_owa_mail_acc():

    from prefect.blocks.system import JSON, Secret

    json_block = JSON.load("rpa-0710-conta-email", _sync=True).value
    secret_block = Secret.load(json_block['secret_block'], _sync=True)
    user = json_block['id']
    password = secret_block.get()

    return {'user': user, 'password': password}