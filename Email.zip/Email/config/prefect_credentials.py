from prefect.blocks.system import Secret, String

class PrefectCredential:
    def __init__(self):
        self.key = None

        self.regex_str = r"String\(value='(.+?)'\)"

    def get_key(self, block_name: str):
        secret_block = Secret.load(block_name, _sync=True)

        self.key = secret_block.get()

        return self.key
