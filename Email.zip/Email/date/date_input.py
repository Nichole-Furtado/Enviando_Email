from datetime import datetime

def format_str_to_date(date_input: str) -> datetime | None:
    try:
        return datetime.strptime(date_input, "%d/%m/%Y")
    except Exception as e:
        print(f"Erro ao processar a data '{date_input}': {e}")
        return None


