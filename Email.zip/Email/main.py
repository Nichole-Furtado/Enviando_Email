#from prefect import flow, task
from date.date_input import format_str_to_date
from src.attachment import AttachmentExcel, AttachmentImage
from src.template_mail import EmailBuilder
from utils.date_handler import DateHandler, convert_dates
from config.mailer_service import get_credential_owa_mail_acc
from utils.send_mail import EmailSender, execute_process

attachment_instance = AttachmentExcel()
emailbuilder_instance = EmailBuilder()

#@task(name="execute_process", log_prints=True)
def read_attachment():
    print('-----------------------------')
    print('Iniciando o processo de leitura do arquivo')
    attachment_instance.get_attachment()
    print('Leitura do arquivo concluída.')
    print('-----------------------------')

#@task(name="build_body", log_prints=True)
def build_body_subject():
    print('-----------------------------')
    print('Realizando template e-mail')
    subject = emailbuilder_instance.build_subject()
    print('-----------------------------')
    print('Template de e-mail concluído')
    return subject

#@task(name="check_data", log_prints=True)
def check_all_dates(dataframe_excel):
    print('-----------------------------')
    print('Verificando as datas que vão vencer há 15 e 30 dias')
    dataframe_excel = convert_dates(dataframe_excel)
    print('-----------------------------')
    print('Verificação de datas concluídas')
    return dataframe_excel

#@task(name="enviando_email", log_prints=True)
def send_mail_to_employees(dataframe_excel, subject):
    print('-----------------------------')
    print('Iniciando envio de emails aos colaboradores')
    credentials = get_credential_owa_mail_acc()
    email_sender = EmailSender()
    for _, item in dataframe_excel.iterrows():
        email_sender.mail(item, subject, credentials)
    print('Envio de email aos colaboradores concluído.')

#@flow(name="envia_email_alvará_agencia_0710", log_prints=True)
def main_fn():
    print('*-----------------------------*')
    print('Iniciando RPA')
    read_attachment()
    subject = build_body_subject()
    dataframe_excel = read_attachment()
    dataframe_excel = check_all_dates(dataframe_excel)
    send_mail_to_employees(dataframe_excel, subject)
    print('*-----------------------------*')
    print('Processo concluído')

if __name__ == '__main__':
    main_fn()
    pass
