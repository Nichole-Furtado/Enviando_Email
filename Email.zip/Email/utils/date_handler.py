from datetime import datetime
from date.date_input import format_str_to_date
from src.attachment import AttachmentExcel

class DateHandler:

    def date_now(self) -> datetime:
        return datetime.now()

    def check_data(self, data_vencimento: datetime) -> tuple[bool, str]:
        data_hoje: datetime = self.date_now()
        try:
            diferenca = (data_vencimento - data_hoje).days + 1
        except Exception as Error:
            print(f"Erro ao calcular a diferença de datas: {Error}")
            diferenca = 0

        if 14 < diferenca < 16:
            return True, "b15"
        elif 29 < diferenca < 31:
            return True, "b30"
        else:
            return False, "0"

def convert_dates(dataframe_excel):
    dataframe_excel["VENCIMENTO TAXA 2025"] = dataframe_excel["VENCIMENTO TAXA 2025"].apply(format_str_to_date)
    return dataframe_excel

#        for _, row in df_excel.iterrows():
#            execute_process(row)




