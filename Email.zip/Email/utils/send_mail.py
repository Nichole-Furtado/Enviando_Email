import os
import smtplib
import time
from email import encoders
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from prefect.blocks.system import JSON
from prefect import task
from utils.date_handler import DateHandler

from src.attachment import AttachmentImage, AttachmentExcel
from config.mailer_service import SMTPConfig, get_credential_owa_mail_acc
from src.template_mail import EmailBuilder

class EmailSenter:
    def __init__(self):
        smtp_config = SMTPConfig()
        self.server_url = SMTPConfig.config['server_url']
        self.port = SMTPConfig.config['port']

class EmailSender:
    def __init__(self):
        self.smtp_connection = EmailSenter()
        self.attachment_image = AttachmentImage()
        self.dir_imagem_sicredi = self.attachment_image.directory_image_sicredi()

    def send_mail(self, receiver_email: list, subject: str, body: str, credentials: dict):
        message = MIMEMultipart()
        message['From'] = credentials['user']
        message['To'] = 'nichole_furtado@sicredi.com.br'  # ------------------------AJUSTAR DEPOIS
        message['Cc'] = ''
        message['Subject'] = subject

        message.attach(MIMEText(body, 'html'))

        with open(self.dir_imagem_sicredi, 'rb') as arquivo:
            imagem_sicredi = MIMEImage(arquivo.read())
            imagem_sicredi.add_header('Content-ID', '<imagem_sicredi>')
            message.attach(imagem_sicredi)

        server = smtplib.SMTP(self.smtp_connection.server_url, self.smtp_connection.port)
        server.starttls()
        server.login(password=credentials['password'], user=credentials['user'])
        a = message.get_payload()
        server.sendmail(credentials['user'], receiver_email, message.as_string())
        server.quit()

    def mail(self, item: object, diferenca: str) -> None:
        receiver_email = []
        credentials = get_credential_owa_mail_acc()
    #   if item["E-MAIL GAO"]:
    #        receiver_email.append(item["E-MAIL GAO"])
    #    if item["E-MAIL GA"]:
    #       receiver_email.append(item["E-MAIL GA"])
    #coop0710_contasapagar@sicredi.com.br
        receiver_email.append("nichole_furtado@sicredi.com.br")
        email_builder = EmailBuilder()
        subject = email_builder.build_subject()
        body = email_builder.build_body(diferenca)
        #build_body(dia, item["VENCIMENTO TAXA 2025"])
        EmailSender.send_mail(
            receiver_email=receiver_email,
            subject=subject,
            body=body,
            credentials=credentials
        )

def execute_process(item):
    data_vencimento = item["VENCIMENTO TAXA 2025"]
    date_handler = DateHandler()
    start_process = date_handler.check_data(data_vencimento)
    if start_process[0]:
        email_sender = EmailSender()
        email_sender.mail(item, start_process[1])

def main_fn():
    attachment = AttachmentExcel()
    base = attachment.get_attachment()
    for _, item in base.iterrows():
        execute_process(item)