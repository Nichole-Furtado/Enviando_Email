from datetime import datetime
from prefect import flow, task
from src.attachment import AttachmentExcel, AttachmentImage
from src.template_mail import EmailBuilder
from utils.date_handler import DateHandler
from config.mailer_service import SMTPConfig, get_credential_mail_acc
from utils.send_mail import EmailSender


@task(name="read_attachment", log_prints=True)
def read_attachment():
    print('-----------------------------')
    print('Iniciando o processo de leitura do arquivo')
    print('-----------------------------')
    attachment_instance = AttachmentExcel()
    dataframe_excel = attachment_instance.get_attachment()
    print('-----------------------------')
    print('Leitura do arquivo concluída.')
    print('-----------------------------')
    return dataframe_excel


@task(name="validate_due_dates", log_prints=True)
def validate_due_dates(dataframe_excel):
    print('-----------------------------')
    print('Verificando as datas que vão vencer há 15 e 30 dias')
    print('-----------------------------')
    date_handler = DateHandler()
    resultados = date_handler.check_dates_in_dataframe(dataframe_excel)
    print('-----------------------------')
    print('Verificação de datas concluídas')
    print('-----------------------------')
    return dataframe_excel


@task(name="build_body_subject", log_prints=True)
def build_body_subject(due_date):
    print('-----------------------------')
    print('Realizando template e-mail')
    print('-----------------------------')
    emailbuilder_instance = EmailBuilder()
    subject = emailbuilder_instance.build_subject()
    body = emailbuilder_instance.build_body(due_date)
    print('-----------------------------')
    print('Template de e-mail concluído')
    print('-----------------------------')
    return subject, body


@task(name="send_mail_to_employees", log_prints=True)
def send_mail_to_employees(dataframe_excel, subject, body):
    print('-----------------------------')
    print('Iniciando envio de emails aos colaboradores')
    print('-----------------------------')
    email_sender = EmailSender()
    email_sender.process_and_send_emails(dataframe_excel)
    print('-----------------------------')
    print('Envio de emails concluído')
    print('-----------------------------')


@flow(name="envia_email_alvara_agencia", log_prints=True)
def main_fn():
    print('*-----------------------------*')
    print('Iniciando RPA')
    print('-----------------------------')
    dataframe_excel = read_attachment()
    check_result = validate_due_dates(dataframe_excel)
    emailbuilder_instance = EmailBuilder()
    subject = emailbuilder_instance.build_subject()
    send_mail_to_employees(dataframe_excel, subject, check_result)

    print('*-----------------------------*')
    print('Processo concluído')
    print('-----------------------------')

if __name__ == '__main__':
    main_fn()