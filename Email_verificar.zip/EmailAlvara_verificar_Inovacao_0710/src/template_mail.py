from utils.date_handler import DateHandler
from datetime import datetime


class EmailBuilder:

    def build_subject(self) -> str:
        return "⚠️ Aviso Alvará 2025 - Contas a Pagar"

    def __init__(self):
        self.signature = self._build_signature()

    def _build_signature(self) -> str:
        return """
            <br><br><br><br><br><br><br>
            Atenciosamente,
            <br><br>
            <div class="WordSection1">
              <p class="MsoNormal">
                <b><span style="font-size:12.0pt;color:#5A645A">
                  Contas a Pagar
                </span></b><o:p></o:p>
              </p>
              <p class="MsoNormal">
                <span style="font-size:12.0pt;color:#5A645A">
                  Gerência de Operações Administrativas – Sede Administrativa
                </span><o:p></o:p>
              </p>
              <p class="MsoNormal">
                <span style="font-size:12.0pt;color:#5A645A">
                  Sicredi Vanguarda PR/SP/RJ - Medianeira
                </span><o:p></o:p>
              </p>
              <p class="MsoNormal">
                <span style="font-size:12.0pt;color:#5A645A">
                  sicredi.com.br/vanguarda
                </span>
              </p>
              <img width="190" height="55" src="cid:imagem_sicredi">
            </div>
        """

    def build_body(self, due_date: datetime) -> str:

        date_handler = DateHandler()
        status, difference_days = date_handler.check_expiration_date(due_date)

        if status == "Válido":
            if difference_days == "Vence em 15 dias":
                return f"""
                    <!DOCTYPE html>
                    <html>
                      <body>
                        <p>
                          Olá!<br><br>
                          Já enviou o pagamento do Alvará da sua agência?<br><br>
                          Se sim, favor desconsiderar este comunicado!<br>
                          Mas caso ainda não tenha enviado, atentar-se ao prazo de envio, 
                          <b>pois o mesmo vence em 15 dias! 🚨</b><br><br>
                        </p>
                        {self.signature}
                      </body>
                    </html>
                """
            elif difference_days == "Vence em 30 dias":
                return f"""
                    <!DOCTYPE html>
                    <html>
                      <body>
                        <p>
                          Olá!<br><br>
                          Identificamos que o Alvará da agência, <b>vence em 30 dias! 🚨</b><br><br>
                          Por gentileza, providenciar o envio do mesmo para pagamento via Contas a Pagar!<br>
                          O pagamento dentro do prazo nos isenta de possíveis notificações!<br>
                        </p>
                        {self.signature}
                      </body>
                    </html>
                """
        return ""