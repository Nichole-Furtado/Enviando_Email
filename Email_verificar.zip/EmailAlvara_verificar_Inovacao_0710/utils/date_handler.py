from datetime import datetime

class DateHandler:
    def date_now(self) -> datetime:
        """Retorna a data atual."""
        return datetime.now()

    def check_expiration_date(self, due_date: datetime | None) -> tuple[str, str]:
        if due_date is None:
            print("Data de vencimento inválida (None).")
            return "Erro", "Data de vencimento inválida"

        date_today = self.date_now().date()
        due_date = due_date.date()
        difference_days = (due_date - date_today).days

        print(f"Data de vencimento: {due_date}, Diferença de dias: {difference_days}")

        if difference_days == 15:
            return "Válido", "Vence em 15 dias"
        elif difference_days == 30:
            return "Válido", "Vence em 30 dias"
        else:
            return "Inválido", "Não está em 15 ou 30 dias"

    def check_dates_in_dataframe(self, df):
        resultados = []

        for index, row in df.iterrows():
            expiration  = row.get("VENCIMENTO TAXA 2025")

            if expiration  is None or expiration  == '':
                resultados.append((index, "Erro", "Data não encontrada"))
                continue

            # Se a data for string, tenta converter
            if isinstance(expiration , str):
                try:
                    expiration  = datetime.strptime(expiration , "%d/%m/%Y")
                except ValueError:
                    resultados.append((index, "Erro", "Formato de data inválido"))
                    continue

            status, message = self.check_expiration_date(expiration)
            resultados.append((index, status, message))

        return resultados
