import smtplib
#from prefect.blocks.system import JSON

#class SMTPConfig:
#    config = JSON.load("smtp-server-config", _sync=True).value

SMTP_CONFIG = {
    "server_url": "smtp.gmail.com",
    "port": 587,
    "user": "nicholefurtado7@gmail.com",        # <-- coloque seu e-mail do Gmail aqui
    "password": "lfzf kgyx djin atis"           # <-- coloque sua senha de aplicativo aqui
}

def get_credential_mail_acc():
    user = SMTP_CONFIG['user']
    password = SMTP_CONFIG['password']
    return {'user': user, 'password': password}

#    from prefect.blocks.system import JSON, Secret

#    json_block = JSON.load("rpa-0710-conta-email", _sync=True).value
#    secret_block = Secret.load(json_block['secret_block'], _sync=True)
#    user = json_block['id']
#    password = secret_block.get()

#    return {'user': user, 'password': password}