#from prefect import flow, task
#from date.date_input import format_str_to_date
from src.attachment import AttachmentExcel, AttachmentImage
from src.template_mail import EmailBuilder
from utils.date_handler import DateHandler
from config.mailer_service import SMTP_CONFIG, get_credential_mail_acc
from utils.send_mail import EmailSender
from datetime import datetime

attachment_instance = AttachmentExcel()
emailbuilder_instance = EmailBuilder()


# @task(name="execute_process", log_prints=True)
def read_attachment():
    print('-----------------------------')
    print('Iniciando o processo de leitura do arquivo')
    dataframe_excel = attachment_instance.get_attachment()
    print('Leitura do arquivo concluída.')
    print('-----------------------------')
    return dataframe_excel


# @task(name="check_data", log_prints=True)
def check_all_dates(dataframe_excel):
    print('-----------------------------')
    print('Verificando as datas que vão vencer há 15 e 30 dias')
    date_handler = DateHandler()
    resultados = date_handler.check_dates_in_dataframe(dataframe_excel)
    print('Verificação de datas concluídas')
    print('-----------------------------')
    return dataframe_excel


# @task(name="build_body_subject", log_prints=True)
def build_body_subject(due_date):
    print('-----------------------------')
    print('Realizando template e-mail')
    subject = emailbuilder_instance.build_subject()
    body = emailbuilder_instance.build_body(due_date)
    print('Template de e-mail concluído')
    print('-----------------------------')
    return subject, body


# @task(name="send_mail", log_prints=True)
def send_mail_to_employees(dataframe_excel, subject, body):
    print('-----------------------------')
    print('Iniciando envio de emails aos colaboradores')
    credentials = get_credential_mail_acc()
    email_sender = EmailSender()

    for _, item in dataframe_excel.iterrows():
        due_date = item["VENCIMENTO TAXA 2025"]  # Pega a data de vencimento
        status, message = DateHandler().check_data(due_date)  # Verifica a data de vencimento
        if status == "Válido" and (message == "Vence em 15 dias" or message == "Vence em 30 dias"):
            # Aqui é onde você constrói o corpo do e-mail conforme a diferença de dias
            body = emailbuilder_instance.build_body(due_date)  # Atualiza o corpo com a data de vencimento
            email_sender.mail(item, subject, body)  # Envia o e-mail com o corpo gerado

            print(f"E-mail enviado para: {item['EMAIL GAO']} - Vencimento: {due_date.strftime('%d/%m/%Y')} - {message}")

    print('Envio de emails concluído')
    print('-----------------------------')


# @flow(name="envia_email_alvara_agencia", log_prints=True)
def main_fn():
    print('*-----------------------------*')
    print('Iniciando RPA')

    dataframe_excel = read_attachment()
    check_result = check_all_dates(dataframe_excel)

    # Aqui você pega o subject, com base na lógica para cada item
    subject = emailbuilder_instance.build_subject()

    # Envia o e-mail para todos os itens que atendem às condições
    send_mail_to_employees(dataframe_excel, subject, check_result)

    print('*-----------------------------*')
    print('Processo concluído')


if __name__ == '__main__':
    main_fn()