import pandas as pd

class AttachmentExcel:
    def __init__(self):
        self.directory_excel = "C:/Users/nicho/OneDrive/Área de Trabalho/rpa/Teste RPA.xlsx"
 #       self.directory_excel = "C:/Users/nichole_furtado/Desktop/Nova pasta/1. Controle Alvará.xlsx"


    def get_attachment(self):
        dataframe_excel = pd.read_excel(self.directory_excel, sheet_name="2024")
        dataframe_excel = dataframe_excel.drop(dataframe_excel.index[0]).reset_index(drop=True)

        return dataframe_excel

class AttachmentImage:

    def __init__(self):
        self.directory_image_sicredi = "//10.31.62.4/Publico/Assessorias/Assessoria de Inovação/image001.png"

    def image_signature(self):
        return self.directory_image_sicredi