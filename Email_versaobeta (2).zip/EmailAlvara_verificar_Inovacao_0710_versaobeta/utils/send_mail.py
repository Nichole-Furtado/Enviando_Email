import os
import smtplib
import time
from email import encoders
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
#from prefect.blocks.system import JSON
#from prefect import task
from utils.date_handler import DateHandler

from src.attachment import AttachmentImage, AttachmentExcel
#from config.mailer_service import SMTPConfig, get_credential_mail_acc
from config.mailer_service import SMTP_CONFIG, get_credential_mail_acc
from src.template_mail import EmailBuilder

#directory_image_sicredi = "//10.31.62.4/Publico/Assessorias/Assessoria de Inovação/image001.png"

# class EmailSenter:
#    def __init__(self):

#        smtp_config = SMTPConfig()
#        self.server_url = SMTPConfig.config['server_url']
#        self.port = SMTPConfig.config['port']

class EmailSender:
    def __init__(self):
#        self.smtp_connection = EmailSenter()
        self.server_url = SMTP_CONFIG['server_url']
        self.port = SMTP_CONFIG['port']
        self.attachment_image = AttachmentImage()

    def send_mail(self, receiver_email: list, subject: str, body: str, credentials: dict):
        message = MIMEMultipart()
        message['From'] = credentials['user']
        message['To'] = ''  # ------------------------AJUSTAR DEPOIS
        message['Cc'] = ''
        message['Subject'] = subject

        message.attach(MIMEText(body, 'html'))

#        with open(directory_image_sicredi, 'rb') as arquivo:
#            imagem_sicredi = MIMEImage(arquivo.read())
#            imagem_sicredi.add_header('Content-ID', '<imagem_sicredi>')
#            message.attach(imagem_sicredi)

        # Conexão com servidor Gmail
        server = smtplib.SMTP(self.server_url, self.port)
        server.starttls()
        server.login(credentials['user'], credentials['password'])
        server.sendmail(credentials['user'], receiver_email, message.as_string())
        server.quit()

# ----------- Prefect
#        server = smtplib.SMTP(self.smtp_connection.server_url, self.smtp_connection.port)
#        server.starttls()
#        server.login(password=credentials['password'], user=credentials['user'])
#        a = message.get_payload()
#        server.sendmail(credentials['user'], receiver_email, message.as_string())
#        server.quit()

    item = AttachmentExcel()


    def mail(self, item, subject, body):
            receiver_email = []
            credentials = get_credential_mail_acc()
        #   if item["E-MAIL GAO"]:
        #        receiver_email.append(item["E-MAIL GAO"])
        #    if item["E-MAIL GA"]:
        #       receiver_email.append(item["E-MAIL GA"])
        #coop0710_contasapagar@sicredi.com.br
            receiver_email.append('nicholefurtado7@gmail.com')# ------------------------AJUSTAR DEPOIS
            email_builder = EmailBuilder()
            subject = email_builder.build_subject()
            body = email_builder.build_body(item["VENCIMENTO TAXA 2025"])
            #build_body(dia, item["VENCIMENTO TAXA 2025"])
            self.send_mail(
                receiver_email=receiver_email,
                subject=subject,
                body=body,
                credentials=credentials
            )

